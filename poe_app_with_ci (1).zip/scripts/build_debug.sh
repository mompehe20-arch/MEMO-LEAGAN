#!/bin/bash
# Simple build script to assemble a debug APK (requires Android SDK & Java)
set -e
if [ ! -f "./gradlew" ]; then
  echo "gradlew not found. Please run this from the project root."
  exit 1
fi
chmod +x ./gradlew
./gradlew assembleDebug
echo "If the build succeeded, debug APK will be at: app/build/outputs/apk/debug/"
