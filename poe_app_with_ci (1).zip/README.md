PoePreviewApp - Android WebView wrapper for https://poe.com/preview/BrlnHUdYyjo8hiu9LwGn

This is a minimal Android Studio project (Kotlin) that opens the provided URL in a WebView.
Customize app name, icons, colors and splash in the res/ folder.

How to build:
1. Open Android Studio -> "Open" and choose this folder.
2. Let Android Studio sync/upgrade Gradle as needed.
3. Build > Generate Signed Bundle / APK to produce an installable APK.

Files included:
- app/src/main/... Android app sources and resources
- build.gradle (project) and app/build.gradle
- gradle.properties (minimal)
