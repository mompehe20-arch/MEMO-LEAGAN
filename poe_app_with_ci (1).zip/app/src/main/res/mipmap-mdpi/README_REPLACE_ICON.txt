Replace this folder's contents with launcher icons (PNG) for this density.
